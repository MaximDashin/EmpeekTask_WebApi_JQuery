﻿namespace EmpeekTask.Models
{
    public interface IRepository
    {
        InformationViewModel GetLogicalDrives();
        InformationViewModel GetInformation(string id);
    }
}